<?php
error_reporting(0);
session_start();
function addAccountants($data){
    if (file_exists("../json/accountants.json")) {
        $current_content = file_get_contents("../json/accountants.json");
        $array_content = json_decode($current_content, true);
        $new_content = array(
            'Name' => $data["Name"],
            'Email' => $data["Email"],
            'NID' => $data["NID"],
            'Password' => $data["Password"],
            'Gender' => $data["Gender"],
        );
        $array_content[] = $new_content;
        $final_content = json_encode($array_content, JSON_UNESCAPED_SLASHES);
        if (file_put_contents("../json/accountants.json", $final_content)) {
            return true;
        }
    } else {
           return false;
    }
}

function checkLogin($data){
    $isFound=false;
    $data_s = file_get_contents("../json/accountants.json");  
    $data_s = json_decode($data_s, true); 
        foreach($data_s as $row){
            if($row["NID"]==$data["NID"] && $row["Password"]==$data["Password"]){
            $isFound=true;
            break;
            }
        }

        if($isFound){
           $_SESSION["NID"]=$data["NID"]; 
           return true;
       }else{
            return false;
       }
    }

    function getUserInfo($data){
        $isset=false;
        $current = file_get_contents("../json/accountants.json");  
        $current = json_decode($current, true); 
        foreach($current as $value){
            if($value['NID']==$data["NID"])
            {
            $_SESSION['FullName']=$value['Name'];
            $_SESSION['Email']=$value['Email'];
            $_SESSION['Image']=$value['Image']; 
            $_SESSION['Gender']=$value['Gender'];
            $_SESSION['Password']=$value['Password'];
            $isset=true;
            break;
            }
        }
        if($isset){
             return true;
        }else{
             return false;
        }
    }

?>