<?php
include '../model/model.php';
class addAccountant{
    public $error=array(
        'nameErr'=>"",
        'emailErr' =>"",
        'passwordErr'=>"",
        'confirm_passwordErr'=>"",
        'nidErr' =>"",
        'genderErr' =>"",
    );
    public $message="";
  
    function addData($data)
    {
      if (empty($data["Name"])) {
          $this-> error["nameErr"] = "Name is required";
      } else {
          if ((str_word_count($data["Name"])) < 2) {
            $this-> error["nameErr"] = "The name must have at least two word";
          } else {
              if ((preg_match("/[A-Za-z]/", $data["Name"][0])) == 0) {
                $this-> error["nameErr"] = "The name must have start with litter";
              } else {
                  if (preg_match('/^[A-Za-z\s._-]+$/', $data["Name"]) !== 1) {
                    $this-> error["nameErr"] = "Name can contain letter,desh,dot and space";
                  }
              }
          }
      }
  
      if (empty($data["Email"])) {
        $this-> error["emailErr"] = "Email is required";
      } else {
          if (!filter_var($data["Email"], FILTER_VALIDATE_EMAIL)) {
            $this-> error["emailErr"] = "Invalid email format";
          }
      }
  
      if (empty($data["Password"])) {
        $this-> error["passwordErr"] = "Password is required";
      } else {
          if (strlen($data["Password"]) < 9) {
            $this-> error["passwordErr"] = "Password must contain at least 8 character";
          } else {
  
              if (preg_match('/[#$%@]/', $data["Password"]) !== 1) {
                $this-> error["passwordErr"] = "Password have to contain at least one '#' or '$' or '%' or '@'";
              }
          }
      }
  
      if (empty($data["Confirm_Password"])) {
        $this-> error["confirm_passwordErr"] = "Confirm Password is required";
      } else {
          if (strcmp($data["Password"], $data["Confirm_Password"]) !== 0) {
            $this-> error["confirm_passwordErr"] = "Password are not matched";
          }
      }
  
      if (empty($data["NID"])) {
        $this-> error["nidErr"] = "NID required";
      } else {
          if (strlen($data["NID"])!=10) {
            $this-> error["nidErr"] = "NID Must be 10 Numbers";
          }
          if (!is_numeric($data["NID"])) {
            $this-> error["nidErr"] = "NID Must only consists of number";
          }

      }
  
      if (empty($data["Gender"])){
        $this-> error["genderErr"] = "Gender is required";
      }

      if(empty($this-> error["nameErr"]) && empty($this-> error["emailErr"]) && empty($this-> error["nidErr"]) && empty($this-> error["passwordErr"]) && empty($this-> error["confirm_passwordErr"]) && empty($this-> error["genderErr"])){

        if(addAccountants($data)){
            $this->message="Registration Successful";
        }
        else{
            $this->message="Unable to do Registration";
        }

      }
  
    }
    
    function get_error(){
        return $this -> error;
    }

    function get_message(){
        return $this -> message;
    }
}
?>