<?php
include_once '../model/model.php';
class login{
    public $Error=array(
        'nidErr'=>"",
        'passwordErr'=>""
    );
    public $message="";
    public $error="";
    function check_login($data){
          if(empty($this->error["nidErr"]) && empty($this->error["passwordErr"])){
             if(checkLogin($data)){
                 $this->message ="Login Successful";
             }
             else{
                 $this->err_message="NID and Password does not match";
             }
          }
    }

    public $err_message="";

    function get_error(){
        return $this -> error;
    }

    function get_message(){
        return $this -> message;
    }

    function error_message(){
        return $this->err_message;
    }
}
?>