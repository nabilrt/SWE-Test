<?php
session_start();
$NID="";
$Full_Name=$Email=$Gender=$Password=$Image="";
if(!isset($_SESSION["NID"])){
    session_destroy();
    header("location:howner_login.php");
}
if(isset($_SESSION["NID"])){
    $NID=$_SESSION["NID"];

    $data=array(
        'NID'=>$NID
    );

    require_once '../controller/getaccountantData.php';

    $accountant_dashboard=new getDataFromFile($data);

    $accountant_dashboard->checkFromFiles($data);

    $Full_Name=$_SESSION['FullName'];
    $Gender=$_SESSION['Gender'];
    $Email=$_SESSION['Email'];
    $Password=$_SESSION['Password'];

}



?>

<br></br>
<?php
include 'header.php';
?>

<html>
<head>
	<meta charset="utf-8">
	<title>Dashboard</title>
</head>
<body>
    
      <br>
	<div class="intro">
        
        <br>
        <span style="font-family: Rockwell;">
    <?php  
    
    
    echo "Hi, ".$Full_Name;

    ?>
        </span>
    
    <br>
    <a href="log_out.php" target="_self" class="button1" >Log out</a>


    </div>
     <br>
     <br>
    

  <div>
   <table border=1 style="width:800px; border-style: none;border-collapse: collapse; border:2px solid blue">
            
          <tr>
            
        <td  style="width:250px">
            <legend>Account<hr></legend>
            <ul >
                <a href="accountant_dashboard.php" class="button">Dashboard</a><br>
                <a href="#">Manage Payments</a><br>
                <a href="#">Edit Profile</a><br>
                <a href="#">Change Picture</a><br>
                <a href="log_out.php">Log out</a><br>
            </ul>
        </td>
        <td  style="width:550px; vertical-align:top;">
            
            <br> </br>
            &nbsp; &nbsp;
            <?php
                echo " <b>   Welcome , ".$Full_Name."<b>";
            ?>
           </td>
        
        </tr>
    </table> 
   </div><br>
   <?php
   include 'footer.php';
   ?>
</body>
</html>