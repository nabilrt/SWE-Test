<!DOCTYPE html>
<html>
    <link rel="stylesheet" type="text/css" href="../css/footer_styles.css">
    <body>
    <div class="divstyles">
        <p>&copy; <b>Copyright 2021</b></p>
    </div>    
    </body>
</html>