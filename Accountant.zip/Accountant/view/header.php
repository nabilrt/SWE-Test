<!DOCTYPE html>
<html>
    <body>
        <div>
        <span style="font-family: Arial, Helvetica, sans-serif; float:right; position: fixed; top:0; width:98%; text-align:right; padding:8px;">Your Perfect Home, Our Promise</span>
        <span style="font-family: Bahnschrift; position: fixed; top:0; width:100%; padding:8px;"><img src="../images/logo.png" alt="" height="50px" width="50px"><span style="font-family: Londrina Solid; float:left; position: fixed; top:0; width:100%; padding:20px;">Lets Find Home</span></span>
        </div>
    </body>
</html>